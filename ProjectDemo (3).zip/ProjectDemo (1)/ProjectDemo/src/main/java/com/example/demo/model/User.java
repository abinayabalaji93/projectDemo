package com.example.demo.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;





@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="tb_user")

public class User {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long userId;
	@Column(name="userName",nullable=false)
	private String userName;
	@Column(name="lst_4chr_idno")
	private String lst4chrIdno;
	private Integer userUuid;
	private Timestamp effectiveDt;
	private  Timestamp ObsoletedDt;
	private String status;
	@Version
	private Integer version;
	
	@CreatedDate
	private Timestamp createdDt;
	@CreatedBy
	private String createdBy;
	@LastModifiedDate
	private Timestamp lastModifiedDt;
	@LastModifiedBy
	private String lastModifiedBy;
	public User() {
		
	}
	public User(Long userId)
	{
		this.userId=userId;
	}
	
	public Long getUserId() {
		return userId;
	}
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public Integer getUserUuid() {
		return userUuid;
	}
	public void setUserUuid(Integer userUuid) {
		this.userUuid = userUuid;
	}
	public Timestamp getEffectiveDt() {
		return effectiveDt;
	}
	public void setEffectiveDt(Timestamp effectiveDt) {
		this.effectiveDt = effectiveDt;
	}
	public Timestamp getObsoletedDt() {
		return ObsoletedDt;
	}
	public void setObsoletedDt(Timestamp obsoletedDt) {
		ObsoletedDt = obsoletedDt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public Timestamp getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getLastModifiedDt() {
		return lastModifiedDt;
	}
	public void setLastModifiedDt(Timestamp lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public String getLst4chrIdno() {
		return lst4chrIdno;
	}
	public void setLst4chrIdno(String lst4chrIdno) {
		this.lst4chrIdno = lst4chrIdno;
	}
	
}


