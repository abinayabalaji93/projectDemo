package com.example.demo.resolver;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.coxautodev.graphql.tools.GraphQLResolver;
import com.example.demo.Repository.RoleRepository;
import com.example.demo.Repository.UserRepository;
import com.example.demo.model.Role;
import com.example.demo.model.User;


@Component
public class UserResolver implements GraphQLResolver<User>{
@Autowired
 UserRepository userRepository;

@Autowired
RoleRepository roleRepository;



public List <Role> getAllRoles()
{
	return roleRepository.findAll();
}

public List<User> getAllUsers()
{
	return userRepository.findAll();
}

}