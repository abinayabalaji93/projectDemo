package com.example.demo.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


@Table(name="tb_user_role")
@Entity
@EntityListeners(AuditingEntityListener.class)
public class Role {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long roleId;
	private int userUuid;
	private String status;
	private String oem;
	private String aemContentContributor;
	private String aemContentProvider;
	private String aemUserManager;
	
	private String aemPowerUser;
	@OneToOne
	@JoinColumn(name="userUuid", referencedColumnName = "userId",insertable = false,updatable = false)
	private User user;
	@Version
	private Integer version;
	
	@CreatedDate
	private Timestamp createdDt;
	@CreatedBy
	private String createdBy;
	@LastModifiedDate
	private Timestamp lastModifiedDt;
	@LastModifiedBy
	private String lastModifiedBy;
	public Role()
	{
		
	}
	public Long getRoleId() {
		return roleId;
	}
	
	public int getUserUuid() {
		return userUuid;
	}
	public void setUserUuid(int userUuid) {
		this.userUuid = userUuid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOem() {
		return oem;
	}
	public void setOem(String oem) {
		this.oem = oem;
	}
	public String getAemContentContributor() {
		return aemContentContributor;
	}
	public void setAemContentContributor(String aemContentContributor) {
		this.aemContentContributor = aemContentContributor;
	}
	public String getAemContentProvider() {
		return aemContentProvider;
	}
	public void setAemContentProvider(String aemContentProvider) {
		this.aemContentProvider = aemContentProvider;
	}
	public String getAemUserManager() {
		return aemUserManager;
	}
	public void setAemUserManager(String aemUserManager) {
		this.aemUserManager = aemUserManager;
	}
	public String getAemPowerUser() {
		return aemPowerUser;
	}
	public void setAemPowerUser(String aemPowerUser) {
		this.aemPowerUser = aemPowerUser;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public Timestamp getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getLastModifiedDt() {
		return lastModifiedDt;
	}
	public void setLastModifiedDt(Timestamp lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	
}
	
	
	
	
	
	
	