package com.example.demo.resolver;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.example.demo.Repository.RoleRepository;
import com.example.demo.Repository.UserRepository;
import com.example.demo.model.Role;
import com.example.demo.model.User;


@Component
public class Query implements GraphQLQueryResolver {
	private UserRepository userRepository;
	private RoleRepository roleRepository;

	Logger logger=LoggerFactory.getLogger(Query.class);
	

	@Autowired
	  public Query(UserRepository userRepository, RoleRepository roleRepository) {
	    this.userRepository = userRepository;
	    this.roleRepository = roleRepository;
	  }
	
	
	@Transactional
	public Iterable<User> getAllUsers() {
		
		logger.error("Error Happened");
	    return userRepository.findAll();
	  }
	
	@Transactional
	  public Iterable<Role> getAllRoles() {
	    return roleRepository.findAll();
	  }

	}

