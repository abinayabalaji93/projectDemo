package com.example.demo.resolver;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLResolver;
import com.example.demo.Repository.RoleRepository;

import com.example.demo.model.Role;


@Component
public class RoleResolver implements GraphQLResolver<Role> {
	@Autowired
	RoleRepository rolerepository;
	
	public List<Role> getAllRoles()
	{
		
		return rolerepository.findAll();
	}

}
