package com.example.demo.service;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ThreadLocalRandom;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.example.demo.Repository.RoleRepository;
import com.example.demo.Repository.UserRepository;
import com.example.demo.model.Role;
import com.example.demo.model.User;

//import javassist.NotFoundException;

@Component
public class Mutation implements GraphQLMutationResolver {
	private UserRepository userRepository;
	private RoleRepository roleRepository;
	
	@Autowired
	public Mutation(UserRepository userRepository,RoleRepository roleRepository)
	{
		this.roleRepository=roleRepository;
		this.userRepository=userRepository;
	}
	public User createUser(String userName,String lst4chrIdno,Integer useruuid,String userId)
	{
		
		User user=new User();
		user.setUserId(userId);
		user.setUserUuid(useruuid);
		user.setUserName(userName);
		user.setLst4chrIdno(lst4chrIdno);
		user.setEffectiveDt(getRandomDate());
		user.setObsoletedDt(getRandomDate());
		
		userRepository.save(user);
		return user;

	
	}
	  public static Timestamp getRandomDate(){
	        Calendar calendar = Calendar.getInstance();
	        calendar.set(Calendar.YEAR, 1990);
	        calendar.set(Calendar.MONTH, 1);
	        calendar.set(Calendar.DATE, 2);
	        Date date1 = calendar.getTime();
	        calendar.set(Calendar.YEAR, 1996);
	        Date date2 = calendar.getTime();
	        long startMillis = date1.getTime();
	        long endMillis = date2.getTime();
	        long randomMillisSinceEpoch = ThreadLocalRandom
	                .current()
	                .nextLong(startMillis, endMillis);

	        return new Timestamp(randomMillisSinceEpoch);
	    }
	
	
	 // @Transactional(readOnly=true)
	  public Role createRole(String roleId,String status,String useruuid, String aemContentContributor,String oem,String aemContentProvider,String aemPowerUser,
			  String aemUserManager,String aemItAdmin)
		{
		Role role =new Role();
		role.setRoleId(roleId);
		role.setUserUuid(useruuid);
		role.setStatus(status);	
		role.setOem(oem);
		role.setAemContentContributor(aemContentContributor);
		role.setAemContentProvider(aemContentProvider);
		role.setAemPowerUser(aemPowerUser);
		role.setAemUserManager(aemUserManager);
		role.setAemItAdmin(aemItAdmin);
		role.setVersion(1);
		
		System.out.println(role);
		
		roleRepository.save(role);
		return role;
	}
	
	
	
	
	
}
