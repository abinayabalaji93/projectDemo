package com.example.demo.model;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="tb_user")

public class User extends Audit{
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private String userId;
	
	
	private String userName;
	
	@Column(name="lst_4chr_idno")
	private String lst4chrIdno;
	
	private Integer userUuid;
	
	private Timestamp effectiveDt;
	
	private Timestamp obsoletedDt;
	
	private char status;
	
	@OneToOne( fetch = FetchType.LAZY,cascade = CascadeType.ALL, mappedBy = "user")
	@JoinColumn(name="userId", referencedColumnName = "userUuid",insertable =  true, updatable = true)
	Role role;

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLst4chrIdno() {
		return lst4chrIdno;
	}

	public void setLst4chrIdno(String lst4chrIdno) {
		this.lst4chrIdno = lst4chrIdno;
	}

	public Integer getUserUuid() {
		return userUuid;
	}

	public void setUserUuid(Integer userUuid) {
		this.userUuid = userUuid;
	}

	public Timestamp getEffectiveDt() {
		return effectiveDt;
	}

	public void setEffectiveDt(Timestamp effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public Timestamp getObsoletedDt() {
		return obsoletedDt;
	}

	public void setObsoletedDt(Timestamp obsoletedDt) {
		this.obsoletedDt = obsoletedDt;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	} 
	
	
	

}