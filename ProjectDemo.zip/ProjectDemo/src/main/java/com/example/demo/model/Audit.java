package com.example.demo.model;


import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import javax.persistence.Version;
import java.sql.Timestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;




@Embeddable
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class Audit {

	
	 @Column(name = "version")
		@Version
		protected int version;

	
	
	//@Temporal(TemporalType.TIME)
	@CreatedDate
	@Column(name="created_dt" ,updatable=false)
	protected Timestamp createdDt;
	
	
	@CreatedBy
	@Column(name="created_by" ,updatable=false)
	protected String createdBy;
	
	
	@LastModifiedDate
	//@Temporal(TemporalType.TIME)
	protected Timestamp lastModifiedDt;
	
	@LastModifiedBy
	protected String lastModifiedBy;

}	