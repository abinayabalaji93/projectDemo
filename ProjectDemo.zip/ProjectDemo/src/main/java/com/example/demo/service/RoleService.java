package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.coxautodev.graphql.tools.GraphQLResolver;
import com.example.demo.Repository.RoleRepository;
import com.example.demo.model.Role;


@Service
@Transactional
public class RoleService implements GraphQLResolver<Role> {

	@Autowired
	RoleRepository roleRepository; 
	
	public List<Role> getAllRoles()
	{
		return roleRepository.findAll();
	}
	
	
}