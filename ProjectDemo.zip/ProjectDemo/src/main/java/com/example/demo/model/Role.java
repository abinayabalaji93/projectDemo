package com.example.demo.model;



import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;





@Table(name="tb_role")
@Entity
@EntityListeners(AuditingEntityListener.class)
public class Role extends Audit  {
	
	
	
	private String roleId;
	@Id
	private String userUuid;
	private String status;
	private String oem;
	
	private String aemContentContributor;
	
	private String aemContentProvider;
	
	private String aemUserManager;
	
	private String aemItAdmin;
	
    private String aemPowerUser;
	 @Column(name = "version")
	//@Version
	protected int version;

	
	

   
	@OneToOne()
	@JoinColumn(name="userUuid", referencedColumnName = "userId",insertable = false,updatable = false)
	private User user;
	public Role()
	{
		
	}
	
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) 
	{
		this.roleId = roleId;
	}




	public String getUserUuid() {
		return userUuid;
	}
	public void setUserUuid(String  userUuid) {
		this.userUuid = userUuid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOem() {
		return oem;
	}
	public void setOem(String oem) {
		this.oem = oem;
	}
	public String getAemContentContributor() {
		return aemContentContributor;
	}
	public void setAemContentContributor(String aemContentContributor) {
		this.aemContentContributor = aemContentContributor;
	}
	public String getAemContentProvider() {
		return aemContentProvider;
	}
	public void setAemContentProvider(String aemContentProvider) {
		this.aemContentProvider = aemContentProvider;
	}
	public String getAemUserManager() {
		return aemUserManager;
	}
	public void setAemUserManager(String aemUserManager) {
		this.aemUserManager = aemUserManager;
	}
	public String getAemPowerUser() {
		return aemPowerUser;
	}
	public void setAemPowerUser(String aemPowerUser) {
		this.aemPowerUser = aemPowerUser;
	}
	
	public String getAemItAdmin() {
		return aemItAdmin;
	}
	public void setAemItAdmin(String aemItAdmin) {
		this.aemItAdmin = aemItAdmin;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	

	@Override
	public String toString() {
		return "Role [roleId=" + roleId + ", userUuid=" + userUuid + ", status=" + status + ", oem=" + oem
				+ ", aemContentContributor=" + aemContentContributor + ", aemContentProvider=" + aemContentProvider
				+ ", aemUserManager=" + aemUserManager + ", aemItAdmin=" + aemItAdmin + ", aemPowerUser=" + aemPowerUser
				+ ", user=" + user + "]";
	}

	
	
}
	
	
	
	
	
	
	