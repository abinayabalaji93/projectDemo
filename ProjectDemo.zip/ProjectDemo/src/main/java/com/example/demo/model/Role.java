package com.example.demo.model;



import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;


@Table(name="tb_user_role")
@Entity
@EntityListeners(AuditingEntityListener.class)
public class Role extends Audit {
	
	
	
	private String roleId;
	@Id
	private String userUuid;
	private String status;
	private String oem;
	private String aemContentContributor;
	private String aemContentProvider;
	private String aemUserManager;
	
	private String aemPowerUser;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="userUuid", referencedColumnName = "userId",insertable = false,updatable = false)
	private User user;
	public Role()
	{
		
	}
	public String setRoleId(String roleId) {
		return roleId;
	}
	
	public String getUserUuid() {
		return userUuid;
	}
	public void setUserUuid(String  userUuid) {
		this.userUuid = userUuid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOem() {
		return oem;
	}
	public void setOem(String oem) {
		this.oem = oem;
	}
	public String getAemContentContributor() {
		return aemContentContributor;
	}
	public void setAemContentContributor(String aemContentContributor) {
		this.aemContentContributor = aemContentContributor;
	}
	public String getAemContentProvider() {
		return aemContentProvider;
	}
	public void setAemContentProvider(String aemContentProvider) {
		this.aemContentProvider = aemContentProvider;
	}
	public String getAemUserManager() {
		return aemUserManager;
	}
	public void setAemUserManager(String aemUserManager) {
		this.aemUserManager = aemUserManager;
	}
	public String getAemPowerUser() {
		return aemPowerUser;
	}
	public void setAemPowerUser(String aemPowerUser) {
		this.aemPowerUser = aemPowerUser;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	
	
}
	
	
	
	
	
	
	