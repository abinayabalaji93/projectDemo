package com.example.demo.mutation;

import java.sql.Timestamp;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.example.demo.Repository.RoleRepository;
import com.example.demo.Repository.UserRepository;
import com.example.demo.model.Role;
import com.example.demo.model.User;

import javassist.NotFoundException;

@Component
public class Mutation implements GraphQLMutationResolver {
	private UserRepository userRepository;
	private RoleRepository roleRepository;
	
	
	@Autowired
	public Mutation(UserRepository userRepository,RoleRepository roleRepository)
	{
		this.roleRepository=roleRepository;
		this.userRepository=userRepository;
	}
	public User createUser(String userName,String lst4chrIdno,Integer useruuid,Timestamp effectiveDt,Timestamp ObsoletedDt,String status,
			int version,Timestamp createdDt,String createdBy,Timestamp lastModifiedDt, String lastModifiedBy)
	{
		
		User user=new User();
		user.setUserUuid(useruuid);
		user.setUserName(userName);
		user.setEffectiveDt(effectiveDt);
		user.setObsoletedDt(ObsoletedDt);
		user.setLst4chrIdno(lst4chrIdno);
		user.setCreatedBy(createdBy);
		user.setVersion(version);
		user.setCreatedDt(createdDt);
		user.setLastModifiedDt(lastModifiedDt);
		user.setLastModifiedBy(lastModifiedBy);
		userRepository.save(user);
		return user;
	
		
	}
	public Role createRole(int UserUuid,String status,String oem,String aemContentContributor,String aemContentProvider,String aemUserManager,String aemPowerUser,
			int version,Timestamp createdDt,String createdBy,Timestamp lastModifiedDt, String lastModifiedBy )
	{
		Role role =new Role();
		role.setAemContentContributor(aemContentContributor);
		role.setAemContentProvider(aemContentProvider);
		role.setAemPowerUser(aemPowerUser);
		role.setAemUserManager(aemUserManager);
		role.setOem(oem);
		role.setUserUuid(UserUuid);
		role.setStatus(status);	
		role.setVersion(version);
		role.setCreatedBy(createdBy);
		role.setCreatedDt(createdDt);
		role.setLastModifiedDt(lastModifiedDt);
		role.setLastModifiedBy(lastModifiedBy);
		roleRepository.save(role);
		return role;
	}
public boolean deleteRole(Long roleid)
{
	roleRepository.deleteById(roleid);
	return true;
}
public Role updateRole( Long roleid,int userUuid,String status,String oem,String aemContentContributor,String aemContentProvider,String aemUserManager,String aemPowerUser) throws NotFoundException{
	Optional<Role> optRole=roleRepository.findById(roleid);
	if(optRole.isPresent())
	{
		Role role=optRole.get();
		if(oem !=null)
			role.setOem(oem);
		if(status!=null)
			role.setStatus(status);
		roleRepository.save(role);
			return role;
	}
	throw new NotFoundException("Not found Role to update!");
}
}
